export const firebaseConfig = {
  apiKey: "AIzaSyDu3PvW5MwtLyl4Z2RveB4eK0PoHihjfOs",
  authDomain: "myblog-85054.firebaseapp.com",
  projectId: "myblog-85054",
  storageBucket: "myblog-85054.appspot.com",
  messagingSenderId: "25568145688",
  appId: "1:25568145688:web:7832a8360fc1bcbd816e6d"
  };