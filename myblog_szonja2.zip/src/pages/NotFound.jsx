import React from 'react'

export const NotFound = () => {
  return (
    <div>Page Not Found</div>
  )
}
